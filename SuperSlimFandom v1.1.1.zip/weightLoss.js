let rightRail = document.querySelector("aside.page__right-rail");
rightRail.remove();

let topAdContainer = document.querySelector("div.top-ads-container");
topAdContainer.remove();

let globalNav = document.querySelector("div.global-navigation");
globalNav.remove();

let globalNavExplore = document.querySelector("div.global-explore-navigation");
globalNavExplore.remove();

let globalFooter = document.querySelector("footer.global-footer");
globalFooter.remove();

let bottomAdContainer = document.querySelector("div[class*='bottom-ads-container']");
bottomAdContainer.remove();

let midPagePlayer = document.querySelector("div#incontent_player");
midPagePlayer.remove();

let adSlots = document.querySelector("div[class*='ad-slot-placeholder']");
adSlots.remove();

let wikiaBar = document.querySelector("div#WikiaBar");
wikiaBar.remove();